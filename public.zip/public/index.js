
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc } from "firebase/firestore";
import { getFunctions } from "firebase/functions";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBhmvqG9yYBV1ACMh2uRx0Ju3pgv4liDOA",
  authDomain: "test3-b6fcf.firebaseapp.com",
  projectId: "test3-b6fcf",
  storageBucket: "test3-b6fcf.appspot.com",
  messagingSenderId: "944837845784",
  appId: "1:944837845784:web:fff6747bf52f7546f5746d",
  measurementId: "G-NTPLV9Q30F"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);

function initializeGame() {
  let playerRef;
  let playerID;

  let myName = "Jonny";
  let x = 3;
  let y = 3;

  const auth = getAuth(app);
  const firestore = getFirestore(app);

  auth.onAuthStateChanged((user) => {
    console.log(user);
    if (user) {
      // Logged in
      playerID = user.uid;
      playerRef = doc(firestore, "players", playerID);

      setDoc(playerRef, {
        id: playerID,
        name: myName,
        x: x,
        y: y,
      }).catch((error) => {
        console.error("Error adding document: ", error);
      });
    } else {
      // Logged out
    }
  });

  auth.signInAnonymously().catch((error) => {
    var errorCode = error.code;
    var errorMessage = error.message;
    console.log(errorCode, errorMessage);
  });
}

initializeGame();
